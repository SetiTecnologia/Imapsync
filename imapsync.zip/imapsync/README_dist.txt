
imapsync-1.592.tgz  is for Unix and Mac users.

imapsync-1.592.zip  is for Windows users.

the file script imapsync for a fast upgrade on Unix.
